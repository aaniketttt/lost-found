import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import SignUp from "./SignUp";
import SignIn from "./SignIn";
import LostItemForm from "./LostItemForm";
import FoundItemForm from "./FoundItemForm";
import ItemCard from "./ItemCard";
import "./App.css";

function App() {
  return (
    <div className="App">
      <header>
        <h1>Lost&Found</h1> {}
        <nav>
          <ul>
            <li>
              <Link to="/signup">Sign Up</Link>
            </li>
            <li>
              <Link to="/signin">Sign In</Link>
            </li>
            <li>
              <Link to="/lostitem">Report Lost Item</Link>
            </li>
            <li>
              <Link to="/founditem">Report Found Item</Link>
            </li>
            <li>
              <Link to="/itemcard">Item Card</Link>
            </li>
          </ul>
        </nav>
      </header>

      <Routes>
        <Route path="/signup" element={<SignUp />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/lostitem" element={<LostItemForm />} />
        <Route path="/founditem" element={<FoundItemForm />} />
        <Route path="/itemcard" element={<ItemCard />} />
      </Routes>
    </div>
  );
}

export default App;
